#!/bin/bash




./send.exe 0 Empty.pat 
./send.exe 1 Empty.pat 
./send.exe 2 Empty.pat 
./send.exe 3 Empty.pat 
./send.exe 4 Empty.pat 
./send.exe 5 Empty.pat 
./send.exe 6 Empty.pat 
./send.exe 7 Empty.pat 
