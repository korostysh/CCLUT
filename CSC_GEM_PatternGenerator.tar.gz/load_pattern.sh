#!/bin/bash
./pat_gen SamplePat.txt
./Send7.sh
./send_d.exe
